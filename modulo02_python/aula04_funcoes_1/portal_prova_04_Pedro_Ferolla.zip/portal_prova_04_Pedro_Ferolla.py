# Prova PYIA - Função 1

# Crie uma função chamada 'media', que receberá três números como argumentos.
# Esta função deve calcular a média aritmética desses três números.
# Para fazer isso, some os três números e, em seguida, divida o resultado por três.
# Por fim, a função deve retornar o valor da média aritmética calculada.

def media(num1: float, num2: float, num3: float):
    media_aritmetica = (num1 + num2 + num3) / 3

    return media_aritmetica
