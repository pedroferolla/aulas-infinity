
biblioteca = {
    "1984": {"autor": "George Orwell", "ano": 1949},
    "O Senhor dos Anéis": {"autor": "J.R.R. Tolkien", "ano": 1954},
    "O Hobbit": {"autor": "J.R.R. Tolkien", "ano": 1937}
}

