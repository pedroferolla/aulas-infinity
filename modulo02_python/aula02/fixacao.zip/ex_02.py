estudantes = {
    "Ana": ["Matemática", "História"],
    "Pedro": ["Biologia", "Física"],
    "Maria": ["Química", "Matemática"]
}