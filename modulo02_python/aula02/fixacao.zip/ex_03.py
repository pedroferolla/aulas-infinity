compras_clientes = {
    "Ana": ["leite", "pão", "maçã"],
    "Pedro": ["pão", "arroz", "leite", "maçã"],
    "Maria": ["maçã", "leite"]
}