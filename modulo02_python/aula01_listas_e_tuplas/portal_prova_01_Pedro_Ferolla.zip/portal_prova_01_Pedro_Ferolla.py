# Prova - Listas e Tuplas

# Crie uma lista contendo seis frutas de sua escolha.
# Depois de ter a lista pronta, converta essa lista em uma tupla.
# Por fim, exiba o conteúdo da tupla resultante para verificar as frutas que foram armazenadas.

lista = ['laranja', 'côco', 'banana', 'maçã', 'abacaxi', 'limão']

tupla = tuple(lista)

print(tupla)
